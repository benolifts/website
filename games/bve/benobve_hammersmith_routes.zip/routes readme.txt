Here is the route hammersmith and city line for bve2, bve4 and openbve.

copy the folder to your route folder















this is copyright - do not distribute in any way
