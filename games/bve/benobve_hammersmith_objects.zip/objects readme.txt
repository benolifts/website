Here are the objects for the hammersmith and city line for bve2, bve4 and openbve.

copy the folder to your object folder















this is copyright - do not distribute in any way
